# android-library
# 1. r-library
- APK 相关：APKInstaller 等
- 应用相关：CrashHandler 等
- 网络相关：本地网络信息、网络请求封装等
- 通知相关
- 播放器：基于 VideoView
- 播放器 2：基于 SurfaceView 和 MediaPlayer
- 工具类集合：定时器、动画、应用信息获取、应用签名工具、图片处理、广播、日期、文件、按键、日志、MD5、网络判断、
Preference、命令行、Service、关机、存储、字符串、系统属性、线程池、线程、Toast、UI、Url、视频、控件等
- 自定义 View：TvRecyclerView、ViewPager、跑马灯、圆角图片等