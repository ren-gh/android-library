package com.r.library.common.player;

import android.widget.FrameLayout;

public class BasePlayerListener implements PlayerListener {
    @Override
    public void onStart(FrameLayout frameLayout, FrameLayout frameLayout2) {
    }

    @Override
    public void onPlaying() {
    }

    @Override
    public void onUpdate(int current) {
    }

    @Override
    public void onLoadingShow() {
    }

    @Override
    public void onLoadingClose() {
    }

    @Override
    public void onPause() {
    }

    @Override
    public void onFast() {
    }

    @Override
    public void onRewind() {
    }

    @Override
    public void onSeekCommpleted() {
    }

    @Override
    public void onError() {
    }

    @Override
    public void onCompleted() {
    }

    @Override
    public void onStop() {
    }

    @Override
    public void onClick() {
    }

    @Override
    public void onFinish() {
    }

    @Override
    public void onSeekChanged(int progress) {
    }

    @Override
    public void onBackClicked() {
    }
}
