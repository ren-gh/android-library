package com.r.library.common.handler;

import android.os.Message;

/**
 * Created by rengh on 18-2-6.
 */

public interface WeakHandlerListener {
    void process(Message msg);
}
